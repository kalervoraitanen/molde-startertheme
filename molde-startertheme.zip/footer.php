		<footer role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">

			<?php /* Show copyright info by default. You can remove this if you want. */ ?>
			&copy; Copyright <?php echo date("Y"); ?>

		</footer>

		<?php wp_footer(); ?>

	</body>

</html>
