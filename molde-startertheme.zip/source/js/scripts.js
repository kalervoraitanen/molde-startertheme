/*
 * Molde Scripts File
*/

jQuery(document).ready(function($) { // Start of jQuery

/*
 * Put your jQuery code here
*/

}); // End of jQuery
